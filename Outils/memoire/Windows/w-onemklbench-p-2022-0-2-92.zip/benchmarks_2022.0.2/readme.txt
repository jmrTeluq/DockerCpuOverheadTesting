This package contains the Intel(R) Distribution for LINPACK* Benchmark
for Windows* OS.

Please refer to the chapter "LINPACK, MP LINPACK, and HPCG Benchmarks" in
online version of Intel(R) oneAPI Math Kernel Library (oneMKL) User's Guide
(http://software.intel.com/en-us/mkl-for-windows-userguide) and readme files
in individual benchmark directories for usage instructions.

These benchmarks are also included in the full product distributions of
Intel(R) oneAPI Math Kernel Library 2022 for Windows* OS
(https://software.intel.com/en-us/intel-mkl).

* Other names and brands may be claimed as the property of others.

